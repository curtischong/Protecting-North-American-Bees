Please refer to the metadata to acquire the data (shape file) for Ecozone, Ecoregion and Ecodistrict.  See links below.


Ecozone: First tier of ELC Classification; Name of Ecozone - see Distribution Section of the metadata at:

	https://www.javacoeapp.lrc.gov.on.ca:443/geonetwork?uuid=08d57ccf-ab9c-4006-948c-a458503a057b 



Ecoregion: Second tier of ELC Classification; Ecoregion code 
Ecorg_name: Name of Ecoregion - see Distribution Section of the metadata at:

	https://www.javacoeapp.lrc.gov.on.ca:443/geonetwork?uuid=1ec3db46-6d91-4e14-a511-625020011258 



Ecodist: Third tier of ELC Classification; Ecodistrict code
Edist_name: Name of Ecodistrict - see Distribution Section of the metadata at:

	https://www.javacoeapp.lrc.gov.on.ca:443/geonetwork?uuid=948bfc19-33d9-4006-abe2-64a74786bc2e


For additional information, please refer to the report available at: http://www.ontario.ca/document/ecosystems-ontario-part-1-ecozones-and-ecoregions

